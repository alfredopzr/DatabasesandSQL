create database if not exists university;
use university;

set foreign_key_checks=0;
drop table if exists faculty;
drop table if exists department;
drop table if exists student;
drop table if exists coursedescription;
set foreign_key_checks=1;

create table department(
did integer(7) primary key,
deptname varchar(30)
);

create table faculty(
facssno varchar(9) primary key,
facname varchar (30),
worksfor integer(7),
foreign key (worksfor) references department(did)
);



alter table department add column chair varchar(9) unique;
alter table department add foreign key(chair) references faculty(facssno) on delete set null;
 
 desc faculty;
 desc department;
 
 insert into faculty values('000000000','John Doe',null);
 insert into department values(1,'CS','000000000');
 update faculty set worksfor=1 where facssno = '000000000';
 select * from faculty;
 select * from department;
 
 
 
create table student(
sid varchar(8) primary key,
stuname varchar(30)
);

alter table student add column mentor varchar(8) references student(sid);
 
 
 create table coursedescription(
cno varchar(10) primary key,
title varchar(50),
credit integer(1),
description varchar(200)
);

create table course_prerequisite(
cno varchar(10),
prerequisite varchar(50),
primary key(cno,prerequisite),
foreign key (cno) references coursedescription(cno)
);

select * from faculty;
delete from faculty where facssno = '000000000';

select * from department;



 




 
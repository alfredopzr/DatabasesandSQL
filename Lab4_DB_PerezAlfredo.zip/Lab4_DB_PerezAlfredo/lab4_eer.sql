CREATE TABLE FACULTY(
facssno varchar(9) primary key,
facname varchar(30)

);

CREATE TABLE INSTRUCTOR(
instid int primary key,
intfacssno varchar(9) references FACULTY(facssno)

);

CREATE TABLE GRADUATE(
gradid int primary key,
gradname varchar(30),
year_of_completion date,
instid int references INSTRUCTOR(instid)
);

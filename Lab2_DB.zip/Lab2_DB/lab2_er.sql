create database TCU_AlfredoPerez;

USE TCU_AlfredoPerez;

DROP TABLE IF EXISTS `department`;

CREATE TABLE `student` (
  `SId` varchar(25) NOT NULL,
  `BDay` float(20) NOT NULL DEFAULT '0',
  `GPA` int(3) NOT NULL,
  `Sex` char(9) NOT NULL,
  `PermTel` int(9) NOT NULL,
  `PermAddress` char(25) NOT NULL,
  `LocalTel` int(9) NOT NULL,
  `CurAddress` char(25) NOT NULL,
  `StuName` char(25) NOT NULL,
  `SSNo` int(9) NOT NULL,
  PRIMARY KEY (`SId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `department` (
	`DId` varchar(25) NOT NULL,
	`DeptName` char(25) NOT NULL,
	`DeptAddress` char(25) NOT NULL,
	`Tel` int(9) NOT NULL,
	PRIMARY KEY (`DId`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `textbook`(
	`ISBN` int(25) NOT NULL,
	`TextName` char(20) NOT NULL,
	`Publisher` char(20) NOT NULL,
	PRIMARY KEY (`ISBN`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `courseOffering` (
	`SeqID` int(25) NOT NULL,
	`Year` int(4) NOT NULL,
	`Semester` int(10) NOT NULL,
	PRIMARY KEY (`SeqID`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `DegreeProgram` (
	`PId` int(25) NOT NULL,
	`ProgName` char(20) NOT NULL,
	`ProgType` char(20) NOT NULL,
	`DeptReq` char(20) NOT NULL,
	`ColReq` char(20) NOT NULL,
	`UnivReq` char(20) NOT NULL,
	PRIMARY KEY (`PId`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `Faculty` (
	`FacSSNo` int(25) NOT NULL,
	`FacName` char(20) NOT NULL,
	`Tel` int(9) NOT NULL,
	`OfficeAddress` varchar(25) NOT NULL,
	PRIMARY KEY (`FacSSNo`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `CourseDescription`(
	`CNo` int(20) NOT NULL,
	`Credits` char(20) NOT NULL,
	`Title` char(20) NOT NULL,
	`Description` char(20) NOT NULL,
	PRIMARY KEY (`CNo`)
)	ENGINE=InnoDB DEFAULT CHARSET=utf8;









